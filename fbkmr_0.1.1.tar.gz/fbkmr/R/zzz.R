.onAttach <- function(libname, pkgname) {
  packageStartupMessage("Please check the Github repository for the tutorial and latest updates: https://github.com/junwei-lu/fbkmr.")
}

release_questions <- function() {
  c(
    "Have you checked the Github repositorary?"
  )
}
