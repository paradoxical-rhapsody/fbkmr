#' @importFrom magrittr %>%
NULL

#' @importFrom magrittr %<>%
NULL

#' @import stats
NULL